//crera la constante para historias 
const historias = document.getElementById('historias');

if(historias[i]){
    

}