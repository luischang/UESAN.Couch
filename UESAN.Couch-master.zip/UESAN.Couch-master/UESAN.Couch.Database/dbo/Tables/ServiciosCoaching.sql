﻿CREATE TABLE [dbo].[ServiciosCoaching] (
    [id_servicio]     INT           IDENTITY (1, 1) NOT NULL,
    [nombre_servicio] VARCHAR (100) NULL,
    [IsActive] BIT NULL, 
    PRIMARY KEY CLUSTERED ([id_servicio] ASC)
);

