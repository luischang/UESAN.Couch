﻿CREATE TABLE [dbo].[TipoPlan] (
    [id_plan]     INT          IDENTITY (1, 1) NOT NULL,
    [nombre_plan] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([id_plan] ASC)
);

